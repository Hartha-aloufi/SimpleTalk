/**
 * generator for randome avatars
 * using unsplash api
 */
function* avatarGenerator() {
    // conter to construct uneuqe urls
    let cnt = 0;

    while (true) {
        yield `https://source.unsplash.com/${48 + cnt}x${48 + cnt}/?person`;

        cnt++;
        if (cnt > 10)
            cnt = 0;
    }
}

const getAvatar = avatarGenerator();
/** Conversation user data. */
export const samples = [
    { id: 101, name: 'Hartha Al-oufi', avatar: getAvatar.next().value,timeStamp: '2020-1-1', lastMessage: 'Hello! are you there' },
    { id: 102, name: 'Omar Al-tamimi', avatar: getAvatar.next().value,timeStamp: '2020-1-1', lastMessage: 'Hello! are you there' },
    { id: 103, name: 'Caroline Al-oufi', avatar: getAvatar.next().value,timeStamp: '2020-1-1', lastMessage: 'Hello! are you there' },
    { id: 105, name: 'Dave Al-oufi', avatar: getAvatar.next().value,timeStamp: '2020-1-1', lastMessage: 'Hello! are you there' },
    { id: 106, name: 'Dave Al-oufi', avatar: getAvatar.next().value,timeStamp: '2020-1-1', lastMessage: 'Hello! are you there My friend I need money' },
    { id: 107, name: 'Dave Al-oufi', avatar: getAvatar.next().value,timeStamp: '2020-1-1', lastMessage: 'Hello! are you there' },
    { id: 108, name: 'Dave Al-oufi', avatar: getAvatar.next().value,timeStamp: '2020-1-1', lastMessage: 'Hello! are you there' },
    { id: 109, name: 'Dave Al-oufi', avatar: getAvatar.next().value,timeStamp: '2020-1-1', lastMessage: 'Hello! are you there' },
]
