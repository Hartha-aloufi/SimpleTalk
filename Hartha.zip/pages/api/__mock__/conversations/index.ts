/**
 * mock api thats handle GET conversations 
 */

 // TODO: support pagination
import { NextApiRequest, NextApiResponse } from 'next'
import { samples } from '../../../../utils/apiMocking/samples-conversations';

export default (_: NextApiRequest, res: NextApiResponse) => {
    try {
        // return static samples
        res.status(200).json(samples)

    } catch (err) {
        res.status(500).json({ statusCode: 500, message: err.message })
    }
}
