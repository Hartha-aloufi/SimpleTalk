import React, { useState, useEffect } from 'react';
import { ActionCreator } from 'redux';
import { useDsipatch } from 'react-redux';

const infinitScroll = ({ fetchAction }) => {
    const dispatch = useDsipatch();
    const [lasElement, setLastElement] = useState();
    const [hasMore, setHasMore] = useState(false);
    const [page, setPage] = useState(0);

    useEffect(() => {
        // setLoading(true)
        dispatch(fetchAction(page)).then(({ totalCount, itemsCount }) => {
            setHasMore(totalCount > itemsCount);
            // setLoading(false)
        }).catch((e) => {
            // TODO: handle error
            // setLoading(false)
        })
    }, []);


    return {
        setLastElement,
        hasMore,
        curPage: page
    }
}